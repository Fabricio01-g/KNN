import pandas as pd

def carregar_dados(caminho):

    return pd.read_csv(caminho)

treino = carregar_dados("knn-dados/sementes_treino.csv")
novas = carregar_dados("knn-dados/sementes_novas.csv")

print(treino.head(10)) # primeiras linhas
print(treino.shape) # (linhas, colunas)
print(treino.info()) # tipos e valores não nulos
print(treino.describe()) # estatísticas das colunas numéricas
print(treino["classe"].value_counts()) # contagem por classe
print(novas.shape)
